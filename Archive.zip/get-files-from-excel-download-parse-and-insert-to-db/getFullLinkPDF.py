### TABLE HAS BEEN CREATED! 
### mycursor.execute ("CREATE TABLE docData (FileName VARCHAR(255), RecordNum VARCHAR(255), NARAReleaseDate VARCHAR(255), FormerlyWithheld VARCHAR(255), Agency VARCHAR(255), DocDate VARCHAR(255), DocType VARCHAR(255), FileNum VARCHAR(255), ToName VARCHAR(255), FromName VARCHAR(255), Title  VARCHAR(255), NumPages VARCHAR(255), Originator VARCHAR(255), RecordSeries VARCHAR(255), ReviewDate VARCHAR(255), Comments VARCHAR(255), PagesReleased VARCHAR(255))")

import mysql.connector
import pandas as pd
import csv

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="password",
  database = "warren"
)
mycursor = mydb.cursor()

FILE_PATH = ("excelDataToDB/jfkExcelTest.xlsx")
xl = pd.ExcelFile(FILE_PATH)
df = xl.parse("Worksheet")

pdfLinkAppend = "https://www.archives.gov/files/research/jfk/releases/"
listOfPdfNames = []
for index, row in df.iterrows():
    pdfNameAlfa = (row["File Name"])
    pdfLinkDownload = (pdfLinkAppend + pdfNameAlfa)
    listOfPdfNames += [pdfLinkDownload]

for i in listOfPdfNames:
    print (i)
    