### TABLE HAS BEEN CREATED! 
### mycursor.execute ("CREATE TABLE docData (FileName VARCHAR(255), RecordNum VARCHAR(255), NARAReleaseDate VARCHAR(255), FormerlyWithheld VARCHAR(255), Agency VARCHAR(255), DocDate VARCHAR(255), DocType VARCHAR(255), FileNum VARCHAR(255), ToName VARCHAR(255), FromName VARCHAR(255), Title  VARCHAR(255), NumPages VARCHAR(255), Originator VARCHAR(255), RecordSeries VARCHAR(255), ReviewDate VARCHAR(255), Comments VARCHAR(255), PagesReleased VARCHAR(255))")

import mysql.connector
import pandas as pd
import csv

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="password",
  database = "warren"
)
mycursor = mydb.cursor()


## DOESN'T WORK WITH XLSX........

### START AS TUPLE, MAKE INTO LIST, APPEND DATA, MAKE INTO TUPLE AGAIN (TUPLES CAN BE UPLOADED TO DB WITH PANDAS)
lineElem = ()
y = list(lineElem)
df = pd.read_excel("excelDataToDB/jfkExcelTest.xls")
firstLine = (df.head(0))
for elem in firstLine:
    elemStr = (str(elem))
    y.append(elemStr)

### INSERT VALUE OF ROW INTO DB:
sql = ("INSERT INTO docData (FileName, RecordNum, NARAReleaseDate, FormerlyWithheld, Agency, DocDate, DocType, FileNum, ToName, FromName, Title, NumPages, Originator, RecordSeries, ReviewDate, Comments, PagesReleased) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)")
val = tuple(y)
print (val)

df = df.drop(labels=0, axis=0)
mycursor.execute(sql, val)
mydb.commit()
