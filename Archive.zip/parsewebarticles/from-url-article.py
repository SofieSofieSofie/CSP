import bs4 as bs
import urllib.request
from urllib.request import Request, urlopen
import re
import heapq
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('maxent_ne_chunker')
nltk.download('words')

from nltk import word_tokenize,sent_tokenize
import newspaper
from newspaper import Article

from datetime import datetime
import uuid
import shortuuid

import mysql.connector

import numpy


mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="password",
  database="newsarticles"
)

### THIS FUNCTIONS EXTRACTS RELEVANT DATA FROM WEB ARTICLE AND INSERTS IT INTO DB
### INPUT IS URL TO WEB ARTICLE



def getArticleData(url):

    # Open the URL as Browser, not as python urllib --- mod_security issue otherwise
    page=urllib.request.Request(url,headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:78.0) Gecko/20100101 Firefox/78.0'}) 
    infile=urllib.request.urlopen(page).read()
    # Read the content as string decoded with utf8 and NOT(!) ISO-8859-1
    article = infile.decode('utf8') 



    # This part generates summary of article
    # The summary is based on most frequent words and the sentences they show up in
    parsed_article = bs.BeautifulSoup(article,'lxml')
    paragraphs = parsed_article.find_all('p')

    article_text = ""

    for p in paragraphs:
        article_text += p.text

    # Removing Square Brackets and Extra Spaces
    article_text = re.sub(r'\[[0-9]*\]', ' ', article_text)
    article_text = re.sub(r'\s+', ' ', article_text)

    # Removing special characters and digits
    formatted_article_text = re.sub('[^a-zA-Z]', ' ', article_text )
    formatted_article_text = re.sub(r'\s+', ' ', formatted_article_text)

    sentence_list = nltk.sent_tokenize(article_text)

    stopwords = nltk.corpus.stopwords.words('english')

    # Dict of list for frequency score for each word in article
    word_frequencies = {}
    for word in nltk.word_tokenize(formatted_article_text):
        if word not in stopwords:
            if word not in word_frequencies.keys():
                word_frequencies[word] = 1
            else:
                word_frequencies[word] += 1

    maximum_frequncy = max(word_frequencies.values())

    for word in word_frequencies.keys():
        word_frequencies[word] = (word_frequencies[word]/maximum_frequncy)

    # More or less the same, but for full sentences, not words
    sentence_scores = {}
    for sent in sentence_list:
        for word in nltk.word_tokenize(sent.lower()):
            if word in word_frequencies.keys():
                if len(sent.split(' ')) < 30:
                    if sent not in sentence_scores.keys():
                        sentence_scores[sent] = word_frequencies[word]
                    else:
                        sentence_scores[sent] += word_frequencies[word]

    # The summary is based on most frequent words and the sentences they show up in
    summary_sentences = heapq.nlargest(7, sentence_scores, key=sentence_scores.get)

    articleSummary = ' '.join(summary_sentences)
    

    # The Python module 'newspaper' has handy built in functions to get data from web article
    article = Article(url)
    article.download()
    article.parse()
    article.nlp()


    articleTitle = (article.title)
    articleText = (article.text)
    articleAuthor1 = article.authors
    articleKeywords1 = article.keywords

    articleKeywords = ','.join(map(str, articleKeywords1)) 
    articleAuthor = ','.join(map(str, articleAuthor1)) 


    # Database wants date to be datetime object - not always accessible in web article
    # Right now error handling is manual...
    articleDate = article.publish_date
    #articleDate = datetime(2021, 4, 16)

    source = url

    # Short UUID as unique ID for referencing/relations
    aruuid = shortuuid.uuid()


    # This part gets all names in article
    sample = articleText

    sentences = nltk.sent_tokenize(sample)
    tokenized_sentences = [nltk.word_tokenize(sentence) for sentence in sentences]
    tagged_sentences = [nltk.pos_tag(sentence) for sentence in tokenized_sentences]
    chunked_sentences = nltk.ne_chunk_sents(tagged_sentences, binary=True)
    
    # Format articleText for my database
    articleText = articleText.encode('utf8')

    # Checks each word in article if it's a name.
    def extract_entity_names(t):
        entity_names = []

        if hasattr(t, 'label') and t.label:
            if t.label() == 'NE':
                entity_names.append(' '.join([child[0] for child in t]))
            else:
                for child in t:
                    entity_names.extend(extract_entity_names(child))

        return entity_names

    entity_names = []
    for tree in chunked_sentences:
        entity_names.extend(extract_entity_names(tree))

    # list with all mentioned names - but only once each
    uniquenames = (set(entity_names))
    articleNames = ','.join(map(str, uniquenames))

    # Insert data into DB
    mycursor = mydb.cursor()

    sql = "INSERT INTO articles (headline, extract, full_text, publishDate, source, tags, names, author, shortuuid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    val = (articleTitle, articleSummary, articleText, articleDate, source, articleKeywords, articleNames, articleAuthor, aruuid)
    mycursor.execute(sql, val)

    mydb.commit()

    print("The article was inserted into the database.")


url = ""
getArticleData(url)
