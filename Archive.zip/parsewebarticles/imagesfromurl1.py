
### CLEAN UP EVENTUALLY
import bs4 as bs
import urllib.request
from urllib.request import Request, urlopen
import re
import heapq
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('maxent_ne_chunker')
nltk.download('words')

from nltk import word_tokenize,sent_tokenize
import newspaper
from newspaper import Article

from datetime import datetime
import uuid
import shortuuid

import mysql.connector

import numpy


mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="password",
  database="newsarticles"
)

### TH





def is_valid(url):
    parsed = urlparse(url)
    return bool(parsed.netloc) and bool(parsed.scheme)


def get_all_images(url):
    # Javascript?????
    session = HTMLSession()
    response = session.get(url)
    response.html.render()
    soup = bs2(response.html.html, "html.parser")
    urls = []
    for img in tqdm(soup.find_all("img"), "Extracting images"):
        img_url = img.attrs.get("src") or img.attrs.get("data-src")
        if not img_url:
            continue
        img_url = urljoin(url, img_url)
        try:
            pos = img_url.index("?")
            img_url = img_url[:pos]
        except ValueError:
            pass
        if is_valid(img_url):
            urls.append(img_url)
    session.close()
    return urls


def download(url, pathname):
    if not os.path.isdir(pathname):
        os.makedirs(pathname)
    response = requests.get(url, stream=True)

    file_size = int(response.headers.get("Content-Length", 0))

    filename = os.path.join(pathname, url.split("/")[-1])







### UNDER DEVELOPMENT: 

    # folderlist = os.listdir(path) # dir is your directory path
    # number_files = len(folderlist)

    # filenames = ""

    # # IMAGESTOTAL = ELEMENTS IN FOLDER
    # for files in os.walk(path):
    #     for filename in files:
    #         filenames = filename
    #         filenames = ", "
    # photolist.append(filenames)
    # photolist.append(number_files)
    # print (photolist)

    # mycursor = mydb.cursor()

    # sql = "INSERT INTO articleimages (headline, filenamescsv, did, imagestotal) VALUES (%s, %s, %s, %s)"
    # val = (headline, filenames, did, number_files)
    # mycursor.execute(sql, photolist)

    # print ("record created")

    # mydb.commit()


def main(url, path):
    # get all images
    imgs = get_all_images(url)
    for img in imgs:
        # for each img, download it
        download(img, path)




