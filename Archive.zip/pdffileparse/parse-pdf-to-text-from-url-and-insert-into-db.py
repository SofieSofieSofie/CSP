import requests
import mysql.connector
import pandas as pd
import csv
import PIL
import pytesseract
import pdf2image
from pdf2image import pdfinfo_from_path, convert_from_path
import os
import pathlib
import shortuuid


def downloadPDF(pdfURL):
    originalurl = pdfURL
    urlnamepdf = pdfURL.rsplit('/', 1)[-1]
    urlname = urlnamepdf.replace(".pdf", "")
    foldername = str(shortuuid.uuid())
    foldername = ("ID-" + foldername)
    parent_dir = "pdfcode/pdf/"
    parent_dir = (parent_dir + foldername)

    pathlib.Path(parent_dir).mkdir(parents=True, exist_ok=True)
    pathtodirectory = (parent_dir + "/" + urlnamepdf)
    ptd = pathtodirectory.replace(".pdf", "")

    r = requests.get(pdfURL)
    
    with open (urlnamepdf, "wb") as f:
        f.write(r.content)
        print ("pdf downloaded from web")
    
    os.rename(urlnamepdf, pathtodirectory)
    print ("pdf file moved to assigned folder: " + pathtodirectory)

    counter = 0
    info = pdfinfo_from_path(pathtodirectory)
    maxPages = info["Pages"]
    for page in range(1, maxPages+1, 10) : 
        pages = convert_from_path(pathtodirectory, dpi=500, first_page=page, last_page = min(page+10-1,maxPages))
        for page in pages:
            ptd = pathtodirectory.replace(".pdf", "")
            counter = counter + 1
            pageXjpeg = ("page" + str(counter) + ".jpg")
            PathFile = str(ptd + pageXjpeg)

            pageXtxt = ("page" + str(counter) + ".txt")
            PathFileTxt = str(ptd + pageXtxt)

            page.save(PathFile, 'JPEG')

            image_file = PIL.Image.open(PathFile)
            string_contents = pytesseract.image_to_string(image_file)

            f = open(PathFileTxt, "x")
            n = f.write(string_contents)
            f.close()
            print ("Page parsed")


    mydbpdf = mysql.connector.connect(
    host="localhost",
    user="root",
    password="password",
    database="epsteindocs"
    )

    items = os.listdir(parent_dir)


    itemsamount = int(len(items))
    itemsamount = itemsamount-1 #pdf file
    itemsamount = itemsamount//2 #jpg + txt files
    pagesamount = (itemsamount)

    pagestotal = itemsamount

    directoryID = str(foldername)
    filename = str(urlname)
    textcontent = ""
    pdffilename = str(urlnamepdf)
    pagenumber = 1

   
    rowlistoflists = []

    while pagesamount > 0:
        rowlist = []
        rowlist.append(directoryID)
        rowlist.append(filename)
        rowlist.append(pagesamount)
        rowlist.append(pagestotal)
        rowlist.append(originalurl)

        pagenumberstr = str(pagesamount)
        path = (ptd + "page" + pagenumberstr + ".txt")

        with open (path) as txtfile:
            pagecontent = txtfile.read().replace("\n", " ")
            rowlist.append(pagecontent)
            rowlistoflists.append(rowlist)
            pagesamount = pagesamount - 1

    rowlistoflists.reverse()
                
    mycursor = mydbpdf.cursor()

    sql = "INSERT INTO parsedfiles (directoryID, filename, pagenum, pagestotal, pdfurl, txtcontent) VALUES (%s, %s, %s, %s, %s, %s)"
    val = (directoryID, filename, pagenumber, pagesamount, pdfURL, textcontent)
    mycursor.executemany(sql, rowlistoflists)

    mydbpdf.commit()

    num = str(pagenumber)
    print(mycursor.rowcount, "pages inserted.")
    print ("\n")
    print ("\n")

    mycursor = mydbpdf.cursor()

    sql = "INSERT INTO filereferences (name, pages, did) VALUES (%s, %s, %s)"
    val = (filename, pagestotal, directoryID)
    mycursor.execute(sql, val)

    print ("record created")

    mydbpdf.commit()


pdfURL = ""
downloadPDF(pdfURL)
