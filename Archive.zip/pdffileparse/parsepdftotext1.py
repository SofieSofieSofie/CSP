import PIL
import pytesseract
import pdf2image
import uuid
import os

filePDF = "testPDF.pdf"
# Convert PDF contents to pages
pages = pdf2image.convert_from_path(filePDF, 500)

# Just using this to give the pages a number
counter = 0
uniqueID = str(uuid.uuid4())

for page in pages:
  

  # page06.jpeg 
  # page06.txt
  scannedFileNameJPEG = "page" + str(counter) + ".jpg"
  scannedFileNameText = "page" + str(counter) + ".txt"

  # uuid + page06.jpeg
  # uuid + page06.txt
  uniqueScannedFileNameJPEG = (uniqueID + "-" + scannedFileNameJPEG)
  uniqueScannedFileNameText = (uniqueID + "-" + scannedFileNameText)
    
  # savePath + uuid + page06.jpeg
  # savePath + uuid + page06.txt
  uniqueScannedFileNameJPEGPath = "saveData/" + uniqueScannedFileNameJPEG
  uniqueScannedFileNameTextPath = "saveData/" + uniqueScannedFileNameText

  # Save image
  page.save(uniqueScannedFileNameJPEGPath, 'JPEG')

  # Open the file as an image
  image_file = PIL.Image.open(uniqueScannedFileNameJPEGPath)

  # Use tesseract to extract the text from the image
  string_contents = pytesseract.image_to_string(image_file)

  # Print the contents to the console
  print (string_contents)

  # Generate text file saveName
  textFileName = (uniqueID + ".txt")

  # Open text file, add parsed text as string, close
  f = open(uniqueScannedFileNameTextPath, "x")
  n = f.write(string_contents)
  f.close()
  counter = counter + 1