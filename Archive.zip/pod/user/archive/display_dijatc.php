<?php
$connect = mysqli_connect('localhost', 'root', 'password');
$select_db = mysqli_select_db($connect, 'podcast');

$id = mysqli_real_escape_string($connect, $_GET['id']);
//Remove LIMIT 1 to show/do this to all results.
$query = 'SELECT parsedtext, epNam FROM dijatc WHERE id = '.$id.' LIMIT 1';
$result = mysqli_query($connect, $query);
$row = mysqli_fetch_array($result);


// Echo page content
echo $row['epNam'];
echo ("<br>");
echo ("<br>");

echo $row['parsedtext'];
?>