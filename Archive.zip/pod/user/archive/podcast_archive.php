<html>
<body>
<?php 
include "db.php";
$query = "SELECT * FROM podcasts";


echo '<table border="0" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial"> </font> </td> 
          <td> <font face="Arial">PODCAST NAME</font> </td> 
          <td> <font face="Arial">PODCAST PATH</font> </td> 
      </tr>';

if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["id"];
        $field2name = $row["podname"];
        $field3name = $row["podlink"];
        

        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td><a href="./archive/'.$field3name.'">Go to archive <a></td> 
                 
              </tr>';
    }
    $result->free();
} 
?>
</body>
</html>