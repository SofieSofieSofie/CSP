


<?php 
include "db.php";
$query = "SELECT * FROM trueanon";


if ($result = $mysqli->query($query)) {
    echo '<table border="0" cellspacing="2" cellpadding="2"> 
        <tr>
            <td> <font face="Arial"> Episode number: </font> </td> 
            <td> <font face="Arial">Episode name: </font> </td> 
            
        </tr>';
    while ($row = $result->fetch_assoc()) {
        $ep_id = $row["id"];
        $ep_name = $row["epNam"];
        $ep_link = $row["epLink"];
        

        echo '<tr>
                  <td>'.$ep_id.'</td> 
                  <td> <a href="'. $ep_link . '"> '. $ep_name.' <a></td> 
                 
              </tr>';
    }
    $result->free();
} 
?>
