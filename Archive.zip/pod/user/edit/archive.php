
<?php
include "db.php";
?>







<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myDIV *").filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    });
</script>
    <title>Podcast Archive</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    
	</head>


  <body>


  
			<div id="nav-placeholder"></div>

			<script>
                $(function(){
                $("#nav-placeholder").load("nav.html");
                });
			</script>

		    <div class="content">
			<h2>Podcast Archive</h2>

            <?php
            $query = mysqli_query($con, "SELECT * FROM NewsArticles");

            while ($row = mysqli_fetch_assoc($query)) {
            $title = $row["headline"];
            $content = $row["extract"];
            $episode = $row["names"];
            }
            ?>

			<div>
                <div id="myDIV">
				<p>These podcast episodes have been transcribed:</p>
                </div>
                <input id="myInput" type="text" placeholder="Search..">

				<table>
					<tr>
						<td>Title:</td>
						<td><?php echo $title;?> - episode number: <?php echo $episode; ?>
					</td>
					</tr>
					<tr>
						<td></td>

                        
						<td><?php echo $content; ?></td>
                        </div>
					</tr>
					<tr>
						<td>Email:</td>
						<td><?=$email?></td>
					</tr>
				</table>
			</div>
		</div>
	</body>











</html>