<?php
	$conn = mysqli_connect("localhost", "root", "password", "db_archive");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>