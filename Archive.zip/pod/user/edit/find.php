<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myDIV *").filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    });
    </script>

    <?php
    include "db.php";
    $query = mysqli_query($con, "SELECT * FROM data");

    while ($row = mysqli_fetch_assoc($query)) {
    $title = $row["podcast_name"];
    $content = $row["podcast_text"];
    $episode = $row["episode"];
    }
    ?>

</head>
<body>

<h2>Filter Anything</h2>
<p>Type something in the input field to search for a specific text inside the div element with id="myDIV":</p>
<input id="myInput" type="text" placeholder="Search..">

<div id="myDIV">
  <p>I am a paragraph.</p>
  <div>I am a div element inside div.</div>
  <button>I am a button</button>
  <button>Another button</button>
  <p>Another paragraph.</p>
  <p><?php echo $title;?> - transcription: <?php echo $content; ?></p>
</div>
  
</body>
</html>