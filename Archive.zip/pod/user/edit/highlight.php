<?php
    include "db.php";
    $query = mysqli_query($con, "SELECT * FROM data");

    while ($row = mysqli_fetch_assoc($query)) {
    $title = $row["podcast_name"];
    $content = $row["podcast_text"];
    $episode = $row["episode"];}


    $arr = explode(" ", $content);

    echo $title;
    echo (" OH LOH LOH HOOOLOOOH ");
    echo $content;
?>