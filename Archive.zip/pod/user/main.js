$(function(){
    



    var words = $("p").first().text().split(/\s+/);
    var text = words.join("</span> <span>");
    $("p").first().html("<span>" + text + "</span>");
    let highlighted;
    $("span").on("click", function() {
    $(highlighted).css("background-color", "");
    $(this).css("background-color", "blue");
    highlighted = this;
    });
  
  });