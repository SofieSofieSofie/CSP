<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	</head>
	<body class="loggedin">
	<div id="nav-placeholder">

</div>

<script>
$(function(){
$("#nav-placeholder").load("nav.html");
});
</script>
		<div class="content">
			<h2>Home Page</h2>
			<p>Welcome back, <?=$_SESSION['name']?>!</p>

			<p> https://medium.com/@nsx1luke/make-a-easy-login-page-for-you-website-with-php-and-mysql-90a739c4d3ff </p>
		</div>
	</body>
</html>