
<?php
include "db.php";



// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}


// We don't have the password or email info stored in sessions so instead we can get the results from the database.
$stmt = $con->prepare('SELECT password, email FROM accounts WHERE id = ?');
// In this case we can use the account ID to get the account info.
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($password, $email);
$stmt->fetch();
$stmt->close();
?>







<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <title>Success! Uploaded file!</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	</head>


  <body class="loggedin">


  
			<div id="nav-placeholder">

			</div>

			<script>
			$(function(){
			$("#nav-placeholder").load("nav.html");
			});
			</script>

		<div class="content">
			<h2>File uploaded successfully</h2>
            <p>The podcast in text format should appear soon in the archive - go there now?</p>
			<div>

            <form action="archive.php" method="post" enctype="multipart/form-data">
            
            <input type="submit" value="Go to archive" name="submit">
            </form>

			</div>
		</div>
	</body>


</html>